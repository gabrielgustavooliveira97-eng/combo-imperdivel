const $=s=>document.querySelector(s);
const titles=["Livro 01 — Adicione seu título","Livro 02 — Adicione seu título","Livro 03 — Adicione seu título","Livro 04 — Adicione seu título"];
// Demonstração visual: este acesso local NÃO confirma pagamento nem protege arquivos.
$("#enter").addEventListener("click",()=>{
 const email=$("#email").value.trim(), code=$("#code").value.trim();
 if(!email||!code){$("#msg").textContent="Informe seu e-mail e o código de acesso.";return;}
 $("#login").hidden=true;$("#library").hidden=false;
 $("#books").innerHTML=titles.map(t=>`<article class="book"><div class="cover">📖</div><h3>${t}</h3><p>PDF ou audiolivro · inserir arquivo</p></article>`).join("");
});
$("#logout").addEventListener("click",()=>{ $("#library").hidden=true;$("#login").hidden=false;});
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));
